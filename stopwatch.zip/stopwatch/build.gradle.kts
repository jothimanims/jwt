plugins {
	java
	id("org.springframework.boot") version "3.4.0-SNAPSHOT"
	id("io.spring.dependency-management") version "1.1.6"
}

group = "com.ma"
version = "0.0.1-SNAPSHOT"

java {
	toolchain {
		languageVersion = JavaLanguageVersion.of(17)
	}
}

repositories {
	mavenCentral()
	maven { url = uri("https://repo.spring.io/milestone") }
	maven { url = uri("https://repo.spring.io/snapshot") }
}

dependencies {
	implementation("org.springframework.boot:spring-boot-starter-web")
	implementation("com.google.code.gson:gson")
	testImplementation("org.springframework.boot:spring-boot-starter-test")
	testRuntimeOnly("org.junit.platform:junit-platform-launcher")
	// https://mvnrepository.com/artifact/io.jsonwebtoken/jjwt
   implementation("io.jsonwebtoken:jjwt:0.11.5")
// https://mvnrepository.com/artifact/io.jsonwebtoken/jjwt-impl
runtimeOnly("io.jsonwebtoken:jjwt-impl:0.11.5")
// https://mvnrepository.com/artifact/io.jsonwebtoken/jjwt-impl
//runtimeOnly group: 'io.jsonwebtoken', name: 'jjwt-impl', version: '0.12.6'
//runtimeOnly group: 'io.jsonwebtoken', name: 'jjwt-jackson', version: '0.12.6'
// https://mvnrepository.com/artifact/io.jsonwebtoken/jjwt-jackson
runtimeOnly("io.jsonwebtoken:jjwt-jackson:0.11.5")
implementation("org.springframework.boot:spring-boot-starter-security:3.3.4")

implementation("com.nimbusds:nimbus-jose-jwt:9.31")


}

tasks.withType<Test> {
	useJUnitPlatform()
}
