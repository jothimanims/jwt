package com.ma.stopwatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StopwatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
