package com.ma.stopwatch.response;

public class LapResponse {
	
	private String lapNumber;
	private String lapTime;
	private String description;
	private String location;
	private String overallTime;
	
	public String getLapNumber() {
		return lapNumber;
	}
	public void setLapNumber(String lapNumber) {
		this.lapNumber = lapNumber;
	}
	public String getLapTime() {
		return lapTime;
	}
	public void setLapTime(String lapTime) {
		this.lapTime = lapTime;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getOverallTime() {
		return overallTime;
	}
	public void setOverallTime(String overallTime) {
		this.overallTime = overallTime;
	}
	
	
}
