package com.ma.stopwatch.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ma.stopwatch.request.LapRequest;
import com.ma.stopwatch.response.LapResponse;
import com.ma.stopwatch.service.StopwatchService;


@RestController
public class StopwatchController {
	
	@Autowired
	private StopwatchService stopwatchService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StopwatchController.class);
	
	/**
	 * 
	 * @param requstList
	 * @return
	 */
	@PostMapping("/createEvent")
	//@CrossOrigin(origins= {"http://localhost:8080"})
	public String createLap(@RequestBody List<LapRequest> requstList ) {
		
		return stopwatchService.createEvent(requstList);
		
	}
	
	/**
	 * 
	 * @return
	 */
	@GetMapping("/lapHistory")
	//@CrossOrigin(origins= {"http://localhost:8080"})
	public List<LapResponse> getLapHistory(){
		
		 return stopwatchService.getLapHistory();
	}
}
