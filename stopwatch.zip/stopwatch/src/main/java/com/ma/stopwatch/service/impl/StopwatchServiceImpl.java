package com.ma.stopwatch.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ma.stopwatch.request.LapRequest;
import com.ma.stopwatch.response.LapResponse;
import com.ma.stopwatch.service.StopwatchService;

@Service
public class StopwatchServiceImpl implements StopwatchService {

	@Value("${lap.file.path}")
	private String filePath;

	@Override
	public String createEvent(List<LapRequest> requstList) {

		File file = new File(filePath + "/output.json");
		ObjectMapper objectMapper = new ObjectMapper();

		try {

			List<LapRequest> existingData = new ArrayList<>();
			if (file.exists()) {
				existingData = objectMapper.readValue(file, new TypeReference<List<LapRequest>>() {
				});
			}

			for (LapRequest request : requstList) {
				existingData.add(request);
			}

			objectMapper.writeValue(file, existingData);
			// objectMapper.writeValue(file, requst);
			return "JSON saved successfully!";
		} catch (IOException e) {
			return "Error saving JSON: " + e.getMessage();
		}

	}

	@Override
	public List<LapResponse> getLapHistory() {

		File file = new File(filePath + "/output.json");
		ObjectMapper objectMapper = new ObjectMapper();
		List<LapResponse> existingData = new ArrayList<>();
		try {

			if (file.exists()) {
				existingData = objectMapper.readValue(file, new TypeReference<List<LapResponse>>() {
				});
			}

			objectMapper.writeValue(file, existingData);
			// objectMapper.writeValue(file, requst);

		} catch (IOException e) {
			e.printStackTrace();
		}

		return existingData;
	}

}
