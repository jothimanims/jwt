package com.ma.stopwatch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ma.stopwatch.service.impl.JwtService;
import com.ma.stopwatch.util.JwtUtils;
import com.nimbusds.jose.JOSEException;

@RestController
@RequestMapping("/auth")
public class AuthContoller {
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private JwtUtils jwtUtils;
	
	/**
	 * 
	 * @return JWT token
	 */
	@PostMapping("/generateToken")
    public String authenticateAndGetToken()  throws JOSEException{
              
		return jwtService.generateToken("User");
		//return jwtUtils.generateToken("User");
    }	
}
