package com.ma.stopwatch.config;

import java.io.IOException;
import java.security.Key;
import java.util.Date;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ma.stopwatch.service.impl.JwtService;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.SignedJWT;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

	//@Value("${jwt.secret}")
	//private String SECRET_KEY;
	
	private String key ="5367566B59703373367639792F423F4528482B4D6251655468576D5A71347437";
	
    @Autowired
    private JwtService jwtService;
    
//    public JwtAuthFilter(AuthenticationManager authenticationManager) {
  //      super(authenticationManager);
    //}


    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        // Retrieve the Authorization header
        String authHeader = request.getHeader("Authorization");
        String token = null;
        String deviceId = null;

        // Check if the header starts with "Bearer "
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            //deviceId = jwtService.extractUsername(token); 
        }

            // Validate token and set authentication
            if (token!=null && !isTokenExpired(token)) {
            	Authentication authentication = new JwtAuthentication(extractAllClaims(token)); 

                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        

        // Continue the filter chain
        filterChain.doFilter(request, response);
    }
    
    // Extract the expiration date from the token
    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    // Extract a claim from the token
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // Extract all claims from the token
     public Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSignKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    // Check if the token is expired
    public Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }
    
    // Get the signing key for JWT token
    public Key getSignKey() {
        byte[] keyBytes = Decoders.BASE64.decode(key);
        return Keys.hmacShaKeyFor(keyBytes);
    }
    /*
    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
    }
    
    public Claims jwtClaims(String token) {
    	
    	Claims claims = null;
    	 try {
    	        JwtParser jwtParser = Jwts.parserBuilder()
    	                .setSigningKey(SECRET_KEY) // Set your secret key here
    	                .build();
    	        Jws<Claims> claimsJws = jwtParser.parseClaimsJws(token);
    	        claims = claimsJws.getBody();

    	        // Access claims in the JWT
    	        String username = claims.getSubject();
    	        // ...
    	    } catch (JwtException e) {
    	        // Handle JWT parsing exceptions
    	        e.printStackTrace();
    	    }	
    	 
    	 return claims;
    }
    
    public boolean validateToken(String token) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(token);
            JWSVerifier verifier = new MACVerifier(key.getBytes());
            signedJWT.verify(verifier);
            
            return signedJWT.verify(verifier);
        } catch (Exception e) {
            return false;
        }
    }*/
}