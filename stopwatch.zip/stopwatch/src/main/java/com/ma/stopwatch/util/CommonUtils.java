package com.ma.stopwatch.util;

public class CommonUtils {
}
