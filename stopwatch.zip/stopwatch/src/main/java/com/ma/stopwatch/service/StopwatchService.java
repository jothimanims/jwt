package com.ma.stopwatch.service;

import java.util.List;

import com.ma.stopwatch.request.LapRequest;
import com.ma.stopwatch.response.LapResponse;

public interface StopwatchService {

	public String createEvent(List<LapRequest> requstList);
	public List<LapResponse>  getLapHistory();
	
}
